from __future__ import annotations

import argparse
from array import array
import json
import math
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

import pronouncing


CLITIC_SUFFIXES = [
    ("n't", "N T"),
    ("'ve", "V"),
    ("'m", "M"),
    ("'re", "R"),
    ("'d", "D"),
    ("'ll", "L"),
    ("'s", "Z"),
]

UNVOICED_FOR_S = {"P", "T", "K", "F", "TH"}
INSTRUMENTAL_DISPLAY_TEXT = ". . ."
AUTO_SECTION_SIZE = 8


def require_file(path: Path, label: str) -> None:
    if not path.exists():
        raise FileNotFoundError(f"{label} does not exist: {path}")
    if not path.is_file():
        raise FileNotFoundError(f"{label} is not a file: {path}")


def require_dir(path: Path, label: str) -> None:
    if not path.exists():
        raise FileNotFoundError(f"{label} does not exist: {path}")
    if not path.is_dir():
        raise FileNotFoundError(f"{label} is not a folder: {path}")


def run_command(command: list[str], cwd: Path | None = None) -> None:
    print("")
    print("Running:")
    print(" ".join(f'"{part}"' if " " in part else part for part in command))
    print("")

    completed = subprocess.run(
        command,
        cwd=str(cwd) if cwd else None,
        text=True,
    )

    if completed.returncode != 0:
        raise RuntimeError(f"Command failed with exit code {completed.returncode}.")


def slugify(value: str) -> str:
    value = str(value).strip().lower()
    value = value.replace("’", "'")
    value = re.sub(r"[^a-z0-9]+", "_", value)
    value = value.strip("_")
    return value or "song"


def section_id_from_label(label: str, index: int) -> str:
    safe = slugify(label).replace("_", "-")
    return f"{safe}-{index:03d}"


def clean_lyric_line(line: str) -> str:
    line = line.strip()
    line = line.replace("’", "'")
    line = line.replace("…", "…")
    line = re.sub(r"\s+", " ", line)
    return line


def is_section_heading(line: str) -> bool:
    return bool(re.match(r"^\[(.+?)\]$", line.strip()))


def section_label_from_heading(line: str) -> str:
    match = re.match(r"^\[(.+?)\]$", line.strip())

    if not match:
        return "Section"

    return match.group(1).strip() or "Section"


def is_comment_line(line: str) -> bool:
    return line.strip().startswith("#")


def is_instrumental_placeholder(line: str) -> bool:
    value = line.strip()

    if value == "…":
        return True

    if value == "...":
        return True

    compact = re.sub(r"\s+", "", value)
    return compact == "..."


def normalise_word(value: str) -> str:
    value = str(value).strip().lower()
    value = value.replace("’", "'")
    value = value.replace("-", "")
    value = re.sub(r"[^a-z0-9']+", "", value)
    return value


def words_from_line(line: str) -> list[str]:
    cleaned = line.replace("’", "'")
    cleaned = cleaned.replace("-", "")
    raw_words = re.findall(r"[A-Za-z0-9']+", cleaned)
    return [normalise_word(word) for word in raw_words if normalise_word(word)]


def make_line_entry(raw_line: str, section_label: str, line_counter: int) -> dict[str, Any] | None:
    line = clean_lyric_line(raw_line)

    if not line:
        return None

    if is_comment_line(line):
        return None

    if is_section_heading(line):
        return None

    if is_instrumental_placeholder(line):
        return {
            "id": f"line-{line_counter:04d}",
            "section": section_label,
            "text": INSTRUMENTAL_DISPLAY_TEXT,
            "display_type": "instrumental",
            "words": [],
        }

    words = words_from_line(line)

    if not words:
        return None

    return {
        "id": f"line-{line_counter:04d}",
        "section": section_label,
        "text": line,
        "display_type": "lyric",
        "words": words,
    }


def parse_lyrics_with_explicit_sections(raw_lines: list[str]) -> tuple[list[dict[str, Any]], str]:
    sections: list[dict[str, Any]] = []
    current_section: dict[str, Any] | None = None
    current_label = "Song"
    line_counter = 0

    def ensure_section(label: str) -> dict[str, Any]:
        nonlocal current_section

        if current_section is None or current_section["label"] != label:
            current_section = {
                "label": label,
                "source": "explicit_heading" if label != "Song" else "implicit_default",
                "lines": [],
            }
            sections.append(current_section)

        return current_section

    ensure_section(current_label)

    for raw_line in raw_lines:
        line = clean_lyric_line(raw_line)

        if not line:
            continue

        if is_comment_line(line):
            continue

        if is_section_heading(line):
            current_label = section_label_from_heading(line)
            ensure_section(current_label)
            continue

        line_counter += 1
        entry = make_line_entry(
            raw_line=raw_line,
            section_label=current_label,
            line_counter=line_counter,
        )

        if entry is None:
            continue

        ensure_section(current_label)["lines"].append(entry)

    sections = [section for section in sections if section["lines"]]
    return sections, "explicit_headings"


def parse_lyrics_with_blank_groups(raw_lines: list[str]) -> tuple[list[dict[str, Any]], str]:
    groups: list[list[str]] = []
    current_group: list[str] = []
    saw_blank_between_content = False
    seen_content = False

    for raw_line in raw_lines:
        line = clean_lyric_line(raw_line)

        if is_comment_line(line):
            continue

        if not line:
            if current_group:
                groups.append(current_group)
                current_group = []
                saw_blank_between_content = True
            continue

        seen_content = True
        current_group.append(raw_line)

    if current_group:
        groups.append(current_group)

    if not groups:
        return [], "blank_groups"

    if len(groups) > 1 and saw_blank_between_content and seen_content:
        sections: list[dict[str, Any]] = []
        line_counter = 0

        for group_index, group in enumerate(groups, start=1):
            section_label = f"Section {group_index}"
            section = {
                "label": section_label,
                "source": "blank_line_group",
                "lines": [],
            }

            for raw_line in group:
                line_counter += 1
                entry = make_line_entry(
                    raw_line=raw_line,
                    section_label=section_label,
                    line_counter=line_counter,
                )

                if entry is not None:
                    section["lines"].append(entry)

            if section["lines"]:
                sections.append(section)

        return sections, "blank_line_groups"

    return parse_lyrics_with_auto_sections(groups[0])


def parse_lyrics_with_auto_sections(raw_lines: list[str]) -> tuple[list[dict[str, Any]], str]:
    display_entries: list[dict[str, Any]] = []
    line_counter = 0

    for raw_line in raw_lines:
        line = clean_lyric_line(raw_line)

        if not line or is_comment_line(line):
            continue

        line_counter += 1
        entry = make_line_entry(
            raw_line=raw_line,
            section_label="Section 1",
            line_counter=line_counter,
        )

        if entry is not None:
            display_entries.append(entry)

    sections: list[dict[str, Any]] = []

    for section_index, start in enumerate(range(0, len(display_entries), AUTO_SECTION_SIZE), start=1):
        label = f"Section {section_index}"
        chunk = display_entries[start:start + AUTO_SECTION_SIZE]

        for entry in chunk:
            entry["section"] = label

        sections.append(
            {
                "label": label,
                "source": "automatic_8_line_group",
                "lines": chunk,
            }
        )

    sections = [section for section in sections if section["lines"]]
    return sections, "automatic_8_line_sections"


def parse_sectioned_lyrics(lyrics_path: Path) -> list[dict[str, Any]]:
    require_file(lyrics_path, "Lyrics file")

    raw_lines = lyrics_path.read_text(encoding="utf-8-sig").splitlines()
    cleaned_lines = [clean_lyric_line(line) for line in raw_lines]
    has_explicit_headings = any(
        is_section_heading(line)
        for line in cleaned_lines
        if line and not is_comment_line(line)
    )

    if has_explicit_headings:
        sections, parser_mode = parse_lyrics_with_explicit_sections(raw_lines)
    else:
        sections, parser_mode = parse_lyrics_with_blank_groups(raw_lines)

    display_line_count = sum(len(section["lines"]) for section in sections)
    lyric_line_count = sum(
        1
        for section in sections
        for line in section["lines"]
        if line.get("display_type") == "lyric"
    )

    if display_line_count == 0:
        raise ValueError("No lyric or instrumental display lines were found. Check your lyrics TXT file.")

    if lyric_line_count == 0:
        raise ValueError(
            "No lyric lines with words were found. The aligner needs at least one real lyric line."
        )

    for section in sections:
        section["parser_mode"] = parser_mode

    return sections


def write_clean_lyrics(sections: list[dict[str, Any]], output_path: Path) -> None:
    output_lines: list[str] = []

    for section in sections:
        for line in section["lines"]:
            if line.get("display_type") != "lyric":
                continue

            output_lines.append(line["text"])

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(output_lines) + "\n", encoding="utf-8")


def write_line_map(
    sections: list[dict[str, Any]],
    output_path: Path,
    source_audio: Path,
    source_lyrics: Path,
) -> None:
    flat_lines: list[dict[str, Any]] = []
    word_index = 0
    section_summaries: list[dict[str, Any]] = []

    for section_index, section in enumerate(sections, start=1):
        section_id = section_id_from_label(section["label"], section_index)
        section_lyric_count = 0
        section_instrumental_count = 0

        for line in section["lines"]:
            display_type = line.get("display_type", "lyric")
            words = line.get("words", [])

            if display_type == "instrumental":
                start_word_index = None
                end_word_index = None
                section_instrumental_count += 1
            else:
                start_word_index = word_index
                end_word_index = word_index + len(words) - 1
                word_index = end_word_index + 1
                section_lyric_count += 1

            flat_lines.append(
                {
                    "id": line["id"],
                    "section_id": section_id,
                    "section": section["label"],
                    "text": line["text"],
                    "display_type": display_type,
                    "words": words,
                    "start_word_index": start_word_index,
                    "end_word_index": end_word_index,
                }
            )

        section_summaries.append(
            {
                "id": section_id,
                "label": section["label"],
                "source": section.get("source", section.get("parser_mode", "unknown")),
                "parser_mode": section.get("parser_mode", "unknown"),
                "line_count": len(section["lines"]),
                "lyric_line_count": section_lyric_count,
                "instrumental_line_count": section_instrumental_count,
            }
        )

    line_map = {
        "schema_version": "kara-line-map-v2",
        "created_by": "kara-creator lyrics-aligner pipeline",
        "source": {
            "audio_file": str(source_audio),
            "lyrics_file": str(source_lyrics),
            "tokenisation": {
                "hyphenated_words": "merged",
                "apostrophes": "kept",
                "instrumental_placeholders": "excluded_from_aligner",
            },
        },
        "parser": {
            "auto_section_size": AUTO_SECTION_SIZE,
            "instrumental_placeholder_inputs": [". . .", "...", "…"],
            "instrumental_placeholder_output": INSTRUMENTAL_DISPLAY_TEXT,
        },
        "line_count": len(flat_lines),
        "lyric_line_count": sum(1 for line in flat_lines if line.get("display_type") == "lyric"),
        "instrumental_line_count": sum(1 for line in flat_lines if line.get("display_type") == "instrumental"),
        "word_count": word_index,
        "sections": section_summaries,
        "lines": flat_lines,
    }

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(line_map, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def strip_stress(phones: str) -> str:
    phones = re.sub(r"\d", "", phones)
    phones = re.sub(r"\s+", " ", phones).strip()
    return phones


def get_direct_phones(word: str) -> str | None:
    options = pronouncing.phones_for_word(word)

    if not options:
        return None

    return strip_stress(options[0])


def plural_s_phone(base_phones: str) -> str:
    phones = base_phones.split()
    last_phone = phones[-1] if phones else ""

    if last_phone in UNVOICED_FOR_S:
        return "S"

    return "Z"


def get_contraction_phones(word: str) -> str | None:
    for suffix, suffix_phones in CLITIC_SUFFIXES:
        if not word.endswith(suffix):
            continue

        base = word[: -len(suffix)]

        if not base:
            return None

        base_phones = get_direct_phones(base)

        if not base_phones:
            return None

        if suffix == "'s":
            suffix_phones = plural_s_phone(base_phones)

        return f"{base_phones} {suffix_phones}".strip()

    return None


def load_custom_pronunciations(project_root: Path) -> dict[str, str]:
    custom_path = project_root / "config" / "custom_pronunciations.json"

    if not custom_path.exists():
        return {}

    data = json.loads(custom_path.read_text(encoding="utf-8"))

    if not isinstance(data, dict):
        raise ValueError(f"Custom pronunciations file must be a JSON object: {custom_path}")

    custom: dict[str, str] = {}

    for raw_word, raw_phones in data.items():
        word = normalise_word(str(raw_word))
        phones = strip_stress(str(raw_phones).upper())

        if word and phones:
            custom[word] = phones

    return custom


def get_word_phones(word: str, custom_pronunciations: dict[str, str]) -> str | None:
    if word in custom_pronunciations:
        return custom_pronunciations[word]

    direct = get_direct_phones(word)

    if direct:
        return direct

    contraction = get_contraction_phones(word)

    if contraction:
        return contraction

    return None


def create_word2phonemes_file(
    word_list_path: Path,
    output_path: Path,
    missing_path: Path,
    custom_pronunciations: dict[str, str],
) -> None:
    require_file(word_list_path, "Word list")

    words: list[str] = []

    for raw_line in word_list_path.read_text(encoding="utf-8-sig").splitlines():
        word = normalise_word(raw_line)

        if word:
            words.append(word)

    words = sorted(set(words))

    output_lines: list[str] = []
    missing_words: list[str] = []

    for word in words:
        phones = get_word_phones(word, custom_pronunciations)

        if phones:
            output_lines.append(f"{word}\t{phones}")
        else:
            missing_words.append(word)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(output_lines) + "\n", encoding="utf-8")

    if missing_path.exists():
        missing_path.unlink()

    if missing_words:
        missing_path.parent.mkdir(parents=True, exist_ok=True)
        missing_path.write_text("\n".join(missing_words) + "\n", encoding="utf-8")
        raise ValueError(
            f"{len(missing_words)} words are missing pronunciations. "
            f"Open this file and send the words here: {missing_path}"
        )



def percentile(values: list[float], percent: float) -> float:
    if not values:
        return 0.0

    ordered = sorted(values)
    index = int(round((len(ordered) - 1) * max(0.0, min(100.0, percent)) / 100.0))
    return ordered[index]


def decode_audio_to_mono_pcm(
    audio_path: Path,
    sample_rate: int,
) -> array:
    command = [
        "ffmpeg",
        "-hide_banner",
        "-loglevel",
        "error",
        "-i",
        str(audio_path),
        "-ac",
        "1",
        "-ar",
        str(sample_rate),
        "-f",
        "s16le",
        "pipe:1",
    ]

    completed = subprocess.run(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )

    if completed.returncode != 0:
        stderr = completed.stderr.decode("utf-8", errors="replace").strip()
        raise RuntimeError(
            "Could not analyse the audio for vocal-start detection. "
            "Check that ffmpeg is installed and available in PowerShell."
            + (f" ffmpeg said: {stderr}" if stderr else "")
        )

    samples = array("h")
    samples.frombytes(completed.stdout)

    if sys.byteorder != "little":
        samples.byteswap()

    return samples


def rms_dbfs(samples: array) -> float:
    if not samples:
        return -120.0

    total = 0.0

    for sample in samples:
        value = float(sample) / 32768.0
        total += value * value

    rms = math.sqrt(total / len(samples))

    if rms <= 0:
        return -120.0

    return 20.0 * math.log10(max(rms, 1e-9))


def detect_first_vocal_start(
    audio_path: Path,
    *,
    sample_rate: int,
    frame_ms: int,
    min_duration_seconds: float,
    pre_roll_seconds: float,
    threshold_db: float | None,
) -> dict[str, Any]:
    samples = decode_audio_to_mono_pcm(
        audio_path=audio_path,
        sample_rate=sample_rate,
    )

    frame_size = max(1, int(sample_rate * frame_ms / 1000))
    frame_count = max(1, math.ceil(len(samples) / frame_size))
    db_values: list[float] = []

    for frame_index in range(frame_count):
        start = frame_index * frame_size
        end = min(len(samples), start + frame_size)
        db_values.append(rms_dbfs(samples[start:end]))

    if not db_values:
        return {
            "status": "no_audio_samples",
            "detected_start_seconds": None,
            "threshold_dbfs": None,
            "noise_floor_dbfs": None,
        }

    noise_floor_db = percentile(db_values, 20)

    if threshold_db is None:
        calculated_threshold = max(noise_floor_db + 12.0, -50.0)
        calculated_threshold = min(calculated_threshold, -25.0)
    else:
        calculated_threshold = float(threshold_db)

    min_frames = max(1, int(math.ceil(min_duration_seconds / (frame_ms / 1000))))
    required_active_frames = max(1, int(math.ceil(min_frames * 0.7)))
    detected_frame: int | None = None

    for frame_index in range(0, max(1, len(db_values) - min_frames + 1)):
        window = db_values[frame_index:frame_index + min_frames]
        active_count = sum(1 for value in window if value >= calculated_threshold)
        average_db = sum(window) / len(window)

        if active_count >= required_active_frames and average_db >= calculated_threshold - 3.0:
            for inner_index, value in enumerate(window):
                if value >= calculated_threshold:
                    detected_frame = frame_index + inner_index
                    break
            break

    if detected_frame is None:
        return {
            "status": "no_sustained_vocal_region_detected",
            "detected_start_seconds": None,
            "threshold_dbfs": round(calculated_threshold, 2),
            "noise_floor_dbfs": round(noise_floor_db, 2),
            "frame_ms": frame_ms,
            "min_duration_seconds": min_duration_seconds,
            "pre_roll_seconds": pre_roll_seconds,
        }

    detected_start = max(0.0, (detected_frame * frame_ms / 1000) - pre_roll_seconds)

    return {
        "status": "detected",
        "detected_start_seconds": round(detected_start, 3),
        "raw_detected_frame_start_seconds": round(detected_frame * frame_ms / 1000, 3),
        "threshold_dbfs": round(calculated_threshold, 2),
        "noise_floor_dbfs": round(noise_floor_db, 2),
        "frame_ms": frame_ms,
        "min_duration_seconds": min_duration_seconds,
        "pre_roll_seconds": pre_roll_seconds,
    }


def read_first_aligner_word_start(aligner_output_path: Path) -> float | None:
    require_file(aligner_output_path, "lyrics-aligner word onset output")

    for raw_line in aligner_output_path.read_text(encoding="utf-8-sig").splitlines():
        line = raw_line.strip()

        if not line:
            continue

        parts = re.split(r"\s+", line)

        if len(parts) < 2:
            continue

        try:
            return float(parts[1])
        except ValueError:
            continue

    return None


def write_offset_aligner_output(
    source_path: Path,
    output_path: Path,
    offset_seconds: float,
) -> None:
    require_file(source_path, "lyrics-aligner word onset output")
    output_lines: list[str] = []

    for raw_line in source_path.read_text(encoding="utf-8-sig").splitlines():
        line = raw_line.strip()

        if not line:
            continue

        parts = re.split(r"\s+", line)

        if len(parts) < 2:
            output_lines.append(raw_line)
            continue

        try:
            start = float(parts[1])
        except ValueError:
            output_lines.append(raw_line)
            continue

        parts[1] = f"{max(0.0, start + offset_seconds):.3f}"
        output_lines.append("\t".join(parts))

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(output_lines) + "\n", encoding="utf-8")


def maybe_apply_vocal_start_correction(
    *,
    aligner_output_path: Path,
    corrected_output_path: Path,
    vocal_start_detection: dict[str, Any],
    enabled: bool,
    min_intro_seconds: float,
    tolerance_seconds: float,
) -> tuple[Path, dict[str, Any]]:
    correction = dict(vocal_start_detection)
    correction["enabled"] = enabled
    correction["min_intro_seconds"] = min_intro_seconds
    correction["tolerance_seconds"] = tolerance_seconds
    correction["correction_applied"] = False
    correction["correction_seconds"] = 0.0
    correction["corrected_aligner_output"] = None

    if not enabled:
        correction["correction_status"] = "disabled"
        return aligner_output_path, correction

    detected_start_raw = correction.get("detected_start_seconds")

    if detected_start_raw is None:
        correction["correction_status"] = "no_detected_vocal_start"
        return aligner_output_path, correction

    detected_start = float(detected_start_raw)

    if detected_start < min_intro_seconds:
        correction["correction_status"] = "detected_intro_short_no_correction"
        return aligner_output_path, correction

    first_word_start = read_first_aligner_word_start(aligner_output_path)
    correction["first_aligner_word_start_seconds"] = None if first_word_start is None else round(first_word_start, 3)

    if first_word_start is None:
        correction["correction_status"] = "no_aligner_word_start_found"
        return aligner_output_path, correction

    correction_seconds = detected_start - first_word_start

    if correction_seconds <= tolerance_seconds:
        correction["correction_status"] = "aligner_start_not_early_enough_to_correct"
        correction["suggested_correction_seconds"] = round(correction_seconds, 3)
        return aligner_output_path, correction

    write_offset_aligner_output(
        source_path=aligner_output_path,
        output_path=corrected_output_path,
        offset_seconds=correction_seconds,
    )

    correction["correction_applied"] = True
    correction["correction_status"] = "shifted_aligner_word_onsets_to_detected_vocal_start"
    correction["correction_seconds"] = round(correction_seconds, 3)
    correction["corrected_aligner_output"] = str(corrected_output_path)

    return corrected_output_path, correction

def clean_previous_aligner_files(aligner_dir: Path, dataset_name: str) -> list[str]:
    removed: list[str] = []

    files_dir = aligner_dir / "files"
    outputs_dir = aligner_dir / "outputs" / dataset_name

    if files_dir.exists():
        for path in files_dir.glob(f"{dataset_name}*"):
            if path.is_file():
                path.unlink()
                removed.append(str(path))
            elif path.is_dir():
                shutil.rmtree(path)
                removed.append(str(path))

    if outputs_dir.exists():
        shutil.rmtree(outputs_dir)
        removed.append(str(outputs_dir))

    return removed


def write_run_manifest(
    manifest_path: Path,
    *,
    safe_name: str,
    dataset_name: str,
    source_audio: Path,
    source_lyrics: Path,
    clean_audio_path: Path,
    clean_lyrics_path: Path,
    line_map_path: Path,
    word_review_path: Path,
    draft_path: Path,
    sections: list[dict[str, Any]],
    removed_files: list[str],
    vocal_start_detection: dict[str, Any] | None = None,
    aligner_vad_threshold: float | None = None,
) -> None:
    manifest = {
        "schema_version": "kara-run-manifest-v2",
        "song_name": safe_name,
        "dataset_name": dataset_name,
        "source": {
            "audio_file": str(source_audio),
            "lyrics_file": str(source_lyrics),
        },
        "prepared_inputs": {
            "audio_file": str(clean_audio_path),
            "lyrics_file": str(clean_lyrics_path),
            "line_map_json": str(line_map_path),
        },
        "outputs": {
            "word_review_json": str(word_review_path),
            "draft_json": str(draft_path),
        },
        "parser": {
            "auto_section_size": AUTO_SECTION_SIZE,
            "instrumental_placeholder_inputs": [". . .", "...", "…"],
            "instrumental_placeholder_output": INSTRUMENTAL_DISPLAY_TEXT,
            "aligner_lyrics_exclude_instrumentals": True,
            "lyrics_aligner_vad_threshold": aligner_vad_threshold,
        },
        "sections": [
            {
                "label": section["label"],
                "source": section.get("source", section.get("parser_mode", "unknown")),
                "parser_mode": section.get("parser_mode", "unknown"),
                "line_count": len(section["lines"]),
                "lyric_line_count": sum(1 for line in section["lines"] if line.get("display_type") == "lyric"),
                "instrumental_line_count": sum(1 for line in section["lines"] if line.get("display_type") == "instrumental"),
            }
            for section in sections
        ],
        "vocal_start_detection": vocal_start_detection or {"enabled": False},
        "cleanup": {
            "removed_previous_aligner_files": removed_files,
        },
    }

    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def run_pipeline(
    project_root: Path,
    audio_path: Path,
    lyrics_path: Path,
    name: str,
    aligner_dir: Path,
    clean_previous: bool,
    auto_vocal_start_correction: bool,
    vocal_start_min_intro_seconds: float,
    vocal_start_correction_tolerance_seconds: float,
    vocal_start_threshold_db: float | None,
    vocal_start_min_duration_seconds: float,
    vocal_start_preroll_seconds: float,
    aligner_vad_threshold: float,
) -> None:
    require_file(audio_path, "Input vocal MP3")
    require_file(lyrics_path, "Input lyrics TXT")
    require_dir(aligner_dir, "lyrics-aligner folder")

    safe_name = slugify(name)
    dataset_name = f"kara_{safe_name}"

    run_dir = project_root / "alignment_lab" / "runs" / safe_name
    run_audio_dir = run_dir / "audio"
    run_lyrics_dir = run_dir / "lyrics"

    clean_audio_path = run_audio_dir / f"{safe_name}{audio_path.suffix.lower()}"
    clean_lyrics_path = run_lyrics_dir / f"{safe_name}.txt"
    line_map_path = run_dir / f"{safe_name}-line-map.json"
    manifest_path = run_dir / f"{safe_name}-run-manifest.json"

    word_review_path = project_root / "outputs" / f"{safe_name}-word-review-lyrics-aligner.json"
    draft_path = project_root / "outputs" / f"{safe_name}-draft-lyrics-aligner-v3.json"
    corrected_aligner_output_path = run_dir / f"{safe_name}-word-onsets-vocal-start-corrected.txt"

    removed_files: list[str] = []

    if clean_previous:
        removed_files = clean_previous_aligner_files(
            aligner_dir=aligner_dir,
            dataset_name=dataset_name,
        )

    custom_pronunciations = load_custom_pronunciations(project_root)
    sections = parse_sectioned_lyrics(lyrics_path)

    run_audio_dir.mkdir(parents=True, exist_ok=True)
    run_lyrics_dir.mkdir(parents=True, exist_ok=True)
    (project_root / "outputs").mkdir(parents=True, exist_ok=True)

    shutil.copy2(audio_path, clean_audio_path)
    write_clean_lyrics(sections, clean_lyrics_path)
    write_line_map(
        sections=sections,
        output_path=line_map_path,
        source_audio=audio_path,
        source_lyrics=lyrics_path,
    )

    if auto_vocal_start_correction:
        vocal_start_detection = detect_first_vocal_start(
            audio_path=clean_audio_path,
            sample_rate=16000,
            frame_ms=50,
            min_duration_seconds=vocal_start_min_duration_seconds,
            pre_roll_seconds=vocal_start_preroll_seconds,
            threshold_db=vocal_start_threshold_db,
        )
    else:
        vocal_start_detection = {
            "enabled": False,
            "status": "disabled",
            "detected_start_seconds": None,
        }

    write_run_manifest(
        manifest_path=manifest_path,
        safe_name=safe_name,
        dataset_name=dataset_name,
        source_audio=audio_path,
        source_lyrics=lyrics_path,
        clean_audio_path=clean_audio_path,
        clean_lyrics_path=clean_lyrics_path,
        line_map_path=line_map_path,
        word_review_path=word_review_path,
        draft_path=draft_path,
        sections=sections,
        removed_files=removed_files,
        vocal_start_detection=vocal_start_detection,
        aligner_vad_threshold=aligner_vad_threshold,
    )

    print("")
    print("Prepared song files.")
    print(f"Run folder:    {run_dir}")
    print(f"Clean audio:   {clean_audio_path}")
    print(f"Clean lyrics:  {clean_lyrics_path}")
    print(f"Line map:      {line_map_path}")
    print(f"Manifest:      {manifest_path}")
    print(f"Custom pronunciations loaded: {len(custom_pronunciations)}")
    print(f"Display lines: {sum(len(section['lines']) for section in sections)}")
    print(f"Lyric lines sent to aligner: {sum(1 for section in sections for line in section['lines'] if line.get('display_type') == 'lyric')}")
    print(f"Instrumental placeholders: {sum(1 for section in sections for line in section['lines'] if line.get('display_type') == 'instrumental')}")
    print(f"lyrics-aligner VAD threshold: {aligner_vad_threshold:g}")

    if auto_vocal_start_correction:
        detected_start = vocal_start_detection.get("detected_start_seconds")
        print(f"Detected first vocal start: {detected_start if detected_start is not None else 'not detected'}")
        if vocal_start_detection.get("threshold_dbfs") is not None:
            print(f"Vocal detection threshold: {vocal_start_detection.get('threshold_dbfs')} dBFS")
    else:
        print("Vocal-start correction: disabled")

    if clean_previous:
        print(f"Previous aligner files removed: {len(removed_files)}")

    run_command(
        [
            sys.executable,
            "make_word_list.py",
            str(run_lyrics_dir),
            "--dataset-name",
            dataset_name,
        ],
        cwd=aligner_dir,
    )

    word_list_path = aligner_dir / "files" / f"{dataset_name}_word_list.txt"
    word2phonemes_path = aligner_dir / "files" / f"{dataset_name}_word2phonemes.txt"
    missing_path = aligner_dir / "files" / f"{dataset_name}_missing_words.txt"

    create_word2phonemes_file(
        word_list_path=word_list_path,
        output_path=word2phonemes_path,
        missing_path=missing_path,
        custom_pronunciations=custom_pronunciations,
    )

    run_command(
        [
            sys.executable,
            "make_word2phoneme_dict.py",
            "--dataset-name",
            dataset_name,
        ],
        cwd=aligner_dir,
    )

    run_command(
        [
            sys.executable,
            "align.py",
            str(run_audio_dir),
            str(run_lyrics_dir),
            "--lyrics-format",
            "w",
            "--onsets",
            "w",
            "--dataset-name",
            dataset_name,
            "--vad-threshold",
            f"{aligner_vad_threshold:g}",
        ],
        cwd=aligner_dir,
    )

    aligner_output_path = (
        aligner_dir
        / "outputs"
        / dataset_name
        / "word_onsets"
        / f"{safe_name}.txt"
    )

    require_file(aligner_output_path, "lyrics-aligner word onset output")

    aligner_output_for_conversion, vocal_start_detection = maybe_apply_vocal_start_correction(
        aligner_output_path=aligner_output_path,
        corrected_output_path=corrected_aligner_output_path,
        vocal_start_detection=vocal_start_detection,
        enabled=auto_vocal_start_correction,
        min_intro_seconds=vocal_start_min_intro_seconds,
        tolerance_seconds=vocal_start_correction_tolerance_seconds,
    )

    print("")
    print(f"Vocal-start correction status: {vocal_start_detection.get('correction_status')}")
    if vocal_start_detection.get("correction_applied"):
        print(f"Timing correction applied: +{vocal_start_detection.get('correction_seconds')} seconds")
        print(f"Corrected aligner output: {aligner_output_for_conversion}")

    write_run_manifest(
        manifest_path=manifest_path,
        safe_name=safe_name,
        dataset_name=dataset_name,
        source_audio=audio_path,
        source_lyrics=lyrics_path,
        clean_audio_path=clean_audio_path,
        clean_lyrics_path=clean_lyrics_path,
        line_map_path=line_map_path,
        word_review_path=word_review_path,
        draft_path=draft_path,
        sections=sections,
        removed_files=removed_files,
        vocal_start_detection=vocal_start_detection,
        aligner_vad_threshold=aligner_vad_threshold,
    )

    run_command(
        [
            sys.executable,
            str(project_root / "tools" / "convert_lyrics_aligner_to_word_review_json.py"),
            "--aligner-output",
            str(aligner_output_for_conversion),
            "--line-map",
            str(line_map_path),
            "--out",
            str(word_review_path),
        ],
        cwd=project_root,
    )

    run_command(
        [
            sys.executable,
            str(project_root / "tools" / "build_karaoke_draft_from_word_starts.py"),
            "--word-review",
            str(word_review_path),
            "--out",
            str(draft_path),
        ],
        cwd=project_root,
    )

    print("")
    print("Done.")
    print("")
    print(f"Word review JSON: {word_review_path}")
    print(f"Draft JSON:       {draft_path}")
    print("")
    print("Open the editor and load:")
    print(f"Audio: {clean_audio_path}")
    print(f"JSON:  {draft_path}")
    print("")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run the local lyrics-aligner karaoke draft pipeline."
    )

    parser.add_argument(
        "--audio",
        required=True,
        help="Path to isolated vocal MP3.",
    )

    parser.add_argument(
        "--lyrics",
        required=True,
        help="Path to exact lyrics TXT. Section headings are optional. Blank lines can create sections. . . . lines are instrumental placeholders.",
    )

    parser.add_argument(
        "--name",
        required=True,
        help="Short song name, for example miss_the_mountains.",
    )

    parser.add_argument(
        "--aligner-dir",
        default=r"C:\Users\mark\kara-creator\alignment_lab\singing-aligners\lyrics-aligner",
        help="Path to the cloned lyrics-aligner folder.",
    )

    parser.add_argument(
        "--keep-previous",
        action="store_true",
        help="Do not clean previous lyrics-aligner files for this song name before running.",
    )

    parser.add_argument(
        "--no-auto-vocal-start-correction",
        action="store_true",
        help="Disable automatic first-vocal-start detection and global onset correction.",
    )

    parser.add_argument(
        "--vocal-start-min-intro-seconds",
        type=float,
        default=5.0,
        help="Only apply vocal-start correction when the detected vocal start is after this many seconds. Default: 5.0.",
    )

    parser.add_argument(
        "--vocal-start-correction-tolerance-seconds",
        type=float,
        default=2.0,
        help="Only shift timings when the aligner starts this many seconds too early. Default: 2.0.",
    )

    parser.add_argument(
        "--vocal-start-threshold-db",
        type=float,
        default=None,
        help="Optional fixed dBFS threshold for vocal-start detection. Leave unset for automatic thresholding.",
    )

    parser.add_argument(
        "--vocal-start-min-duration-seconds",
        type=float,
        default=0.45,
        help="Minimum sustained audio duration required to count as the first vocal region. Default: 0.45.",
    )

    parser.add_argument(
        "--vocal-start-preroll-seconds",
        type=float,
        default=0.35,
        help="Start the detected vocal region this much earlier to avoid clipping the first word. Default: 0.35.",
    )

    parser.add_argument(
        "--vad-threshold",
        type=float,
        default=0.0,
        help="lyrics-aligner VAD threshold. Use 0 for the old behaviour. Try 0.05, 0.1, or 0.2 when quiet backing bleed or separation artefacts may be confusing the aligner. Default: 0.0.",
    )

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    project_root = Path(__file__).resolve().parents[1]

    try:
        run_pipeline(
            project_root=project_root,
            audio_path=Path(args.audio).resolve(),
            lyrics_path=Path(args.lyrics).resolve(),
            name=args.name,
            aligner_dir=Path(args.aligner_dir).resolve(),
            clean_previous=not args.keep_previous,
            auto_vocal_start_correction=not args.no_auto_vocal_start_correction,
            vocal_start_min_intro_seconds=args.vocal_start_min_intro_seconds,
            vocal_start_correction_tolerance_seconds=args.vocal_start_correction_tolerance_seconds,
            vocal_start_threshold_db=args.vocal_start_threshold_db,
            vocal_start_min_duration_seconds=args.vocal_start_min_duration_seconds,
            vocal_start_preroll_seconds=args.vocal_start_preroll_seconds,
            aligner_vad_threshold=args.vad_threshold,
        )
    except Exception as error:
        print("")
        print("Pipeline failed.")
        print(str(error))
        print("")
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
